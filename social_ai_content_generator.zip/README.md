# 📱 AI-Powered Social Media Content Generator

Automatically generate engaging social media captions, relevant hashtags, and expressive emojis based on a keyword or topic — optimized for Instagram, Twitter, and LinkedIn!

## ✨ Features
- Input a topic or idea
- Choose a platform
- Get AI-generated captions, emojis, and hashtags

## 🔧 Tech Stack
- Python
- Hugging Face Transformers
- Gradio

## 🚀 Getting Started

```bash
git clone https://github.com/yourusername/social-ai-content-generator.git
cd social-ai-content-generator
pip install -r requirements.txt
python app.py
```

## 📚 License
MIT
